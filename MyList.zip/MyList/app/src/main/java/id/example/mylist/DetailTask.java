package id.example.mylist;

import static id.example.mylist.LoginActivity.MY_PREFS_NAME;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DetailTask extends AppCompatActivity {
    TextView titlepage, addtitle, adddesc, adddate;
    EditText titledoes, descdoes, datedoes;
    Button btnHapus;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_task);

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String email = prefs.getString("email", "No email");
        titlepage = findViewById(R.id.titlepage);

        addtitle = findViewById(R.id.addtitle);
        adddesc = findViewById(R.id.adddesc);
        adddate = findViewById(R.id.adddate);

        titledoes = findViewById(R.id.titledoes);
        descdoes = findViewById(R.id.descdoes);
        datedoes = findViewById(R.id.datedoes);

        titledoes.setEnabled(false);
        descdoes.setEnabled(false);
        datedoes.setEnabled(false);

        titledoes.setText(getIntent().getStringExtra("title"));
        descdoes.setText(getIntent().getStringExtra("desc"));
        datedoes.setText(getIntent().getStringExtra("date"));

        btnHapus = findViewById(R.id.btnDelete);
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loading = ProgressDialog.show(
                        DetailTask.this,
                        null,
                        "Loading...",
                        true,
                        true
                );
                DatabaseReference mPostReference = FirebaseDatabase.getInstance().getReference()
                        .child(email).child("MyList").child("Does"+getIntent().getStringExtra("key"));
                mPostReference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        loading.dismiss();
                        if (task.isComplete()){
                            startActivity(new Intent(DetailTask.this, MainActivity.class));
                            finish();
                        }else {
                            Toast.makeText(DetailTask.this, "Gagal Menghapus", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}
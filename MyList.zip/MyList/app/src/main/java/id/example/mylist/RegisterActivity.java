package id.example.mylist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText email2, password2;
    Button register;
    FirebaseAuth mAuth;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email2 = findViewById(R.id.etRegisterEmail);
        password2 = findViewById(R.id.etRegisterPassword);
        register = findViewById(R.id.btnRegister);
        mAuth=FirebaseAuth.getInstance();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loading = ProgressDialog.show(
                        RegisterActivity.this,
                        null,
                        "Loading...",
                        true,
                        true
                );
                String email = email2.getText().toString().trim();
                String password= password2.getText().toString().trim();
                if(email.isEmpty())
                {
                    email2.setError("Email is empty");
                    password2.requestFocus();
                    return;
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    email2.setError("Enter the valid email address");
                    password2.requestFocus();
                    return;
                }
                if(password.isEmpty())
                {
                    email2.setError("Enter the password");
                    password2.requestFocus();
                    return;
                }
                if(password.length()<6)
                {
                    email2.setError("Length of the password should be more than 6");
                    password2.requestFocus();
                    return;
                }
                mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            loading.dismiss();;
                            Toast.makeText(RegisterActivity.this,"You are successfully Registered", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                            finish();
                        }
                        else
                        {
                            loading.dismiss();
                            Toast.makeText(RegisterActivity.this,"You are not Registered! Try again",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}